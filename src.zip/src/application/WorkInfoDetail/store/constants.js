export const GET_WORK_INPUT_VALUE = 'workInfoDetail/GET_WORK_INPUT_VALUE'

