import reducer from './reducers'

export { reducer }
