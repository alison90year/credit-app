export const CHANGE_INPUT_VALUE  = 'baseInfoDetail/CHANGE_INPUT_VALUE'
