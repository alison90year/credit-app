import styled from 'styled-px2vw'
export const Content = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  width: 100%;
 background: aqua;
`
