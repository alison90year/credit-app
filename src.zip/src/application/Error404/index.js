import React from "react";

function Error404(){
    return (
        <div>找不到页面</div>
    )
}


export default Error404
